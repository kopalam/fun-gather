import { Script } from "vm";
import { Request } from "vm";


const token = 'eyJ1c2VyX2lkIjoxMDAsInVzZXJfYWNjb3VudCI6IjE4OTIzMDg3NDgxIiwic2Vzc2lvbiI6InNlc3MtWWhFTzYyMjUiLCJyZXFfaWQiOjE1MDg2NX0=.1552442601.ce97357514d142cd1c1dd027a581c9b9';
export default token